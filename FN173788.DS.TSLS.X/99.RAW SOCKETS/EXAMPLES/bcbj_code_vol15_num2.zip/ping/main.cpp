// ---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <vector>
#include <winsock2.h>
#include <iphlpapi.h>
#include <icmpapi.h>

// Ping for non-admin user
// http://support.microsoft.com/kb/170591

/*
The IcmpSendEcho function is exported from the Icmp.dll on Windows 2000.
The IcmpSendEcho function is exported from the Iphlpapi.dll on Windows XP
and later. Windows version checking is not recommended to use this function.
Applications requiring portability with this function across Windows 2000,
Windows XP, Windows Server 2003 and later Windows versions should not statically
link to either the Icmp.lib or the Iphlpapi.lib file. Instead, the application
should check for the presence of IcmpSendEcho in the Iphlpapi.dll with calls to
LoadLibrary and GetProcAddress. Failing that, the application should check for
the presence of IcmpSendEcho in the Icmp.dll with calls to LoadLibrary and
GetProcAddress.

Note that the include directive for Iphlpapi.h header file must be placed before
the Icmpapi.h header file.
 */

#pragma comment( lib, "iphlpapi.lib" )      // XP and later
#pragma comment( lib, "ws2_32.lib" )

#include "main.h"

// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;

// ---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain( TComponent* Owner ) : TForm( Owner )
{
}
// ---------------------------------------------------------------------------
void __fastcall TfrmMain::SendPing( const AnsiString &AIPv4Address,
  const AnsiString &AMessage )
{
  if( AMessage.IsEmpty() )
    throw Exception( "Cannot echo an empty message" );

  // AIPv4Address must be char*

  // IP Address
  IPAddr ipaddr = ::inet_addr( AIPv4Address.c_str() );

  if( INADDR_NONE == ipaddr )
  {
    // try as a domain name
    HOSTENT *hostServer = ::gethostbyname( AIPv4Address.c_str() );

    if( NULL != hostServer )
    {
      if( AF_INET == hostServer->h_addrtype )
        ipaddr = *( ( u_long* ) hostServer->h_addr_list[ 0 ] );
    }
  }

  if ( INADDR_NONE == ipaddr )
  {
    //  int dwError = WSAGetLastError();
    throw Exception( "Unable to resolve IP Address" );
  }

  HANDLE hIcmpFile = ::IcmpCreateFile();

  if ( INVALID_HANDLE_VALUE == hIcmpFile )
    RaiseLastOSError( );

  /* Comment made at http://msdn.microsoft.com/en-us/library/aa366050
  ERROR 11050 (IP_GENERAL_FAILURE)
  The code example does not work under Windows7 (64bit) - It fails with
  "IcmpSendEcho returned error: 11050". It seems that the SendData-buffer
  needs to be at least 18 Bytes large to avoid this error.  I would recommend
  to use the same size the windows ping utility uses by default (32 Bytes).
  */

/*
  // must be char*, using a 32 byte buffer
  const int cMsgLen = std::max( 32, AMessage.Length() + 1 );
  std::vector < byte > SendData( cMsgLen );
  char *pSendData = &( SendData[ 0 ] );

  ::strcpy( pSendData, AMessage.c_str() );

  // The allocated size, in bytes, of the reply buffer. The buffer should be
  // large enough to hold at least one ICMP_ECHO_REPLY structure plus RequestSize
  // bytes of data. On a 64-bit platform, The buffer should be large enough to hold
  // at least one ICMP_ECHO_REPLY32 structure plus RequestSize bytes of data.
  // This buffer should also be large enough to also hold 8 more bytes of data
  // (the size of an ICMP error message).
  DWORD ReplySize = sizeof( ICMP_ECHO_REPLY ) + SendData.size() + 8;
*/

  DWORD ReplySize = sizeof( ICMP_ECHO_REPLY ) + AMessage.Length() + 8;

  std::vector < byte > ABuffer( ReplySize );
  LPVOID ReplyBuffer = &( ABuffer[ 0 ] );

  IP_OPTION_INFORMATION AIPOption;
  ::ZeroMemory( &AIPOption, sizeof( AIPOption ) );

  // TTL
  AIPOption.Ttl = 128;

  // indicates that the packet should not be fragmented.
  AIPOption.Flags = IP_FLAG_DF;

  const DWORD cTimeOut = 1000;

  DWORD dwRetVal = ::IcmpSendEcho(
                      hIcmpFile,
                      ipaddr,
                      //pSendData,
                      //SendData.size(),
                      AMessage.c_str(),
                      AMessage.Length(),
                      &AIPOption,
                      ReplyBuffer,
                      ReplySize,
                      cTimeOut );

  if ( 0 != dwRetVal )
  {
    PICMP_ECHO_REPLY pEchoReply =
      reinterpret_cast < PICMP_ECHO_REPLY >( ReplyBuffer );

    in_addr ReplyAddr;
    ReplyAddr.S_un.S_addr = pEchoReply->Address;

    Log( "Ping message sent to " + edIPv4Address->Text );

    for( DWORD i = 0; i < dwRetVal; ++i )
    {
      Log( "Received " + String( dwRetVal ) +
        String( " icmp message responses" ) );

      Log( "  Received from " + String( inet_ntoa( ReplyAddr ) )
        + " : " + AnsiString( ( char* )( pEchoReply->Data ),
        pEchoReply->DataSize ) );

      Log( "  Status = " + String( pEchoReply->Status ) );

      Log( "  Time = " + String( pEchoReply->RoundTripTime ) + " milliseconds" );
    }
  }
  else
  {
    DWORD dwErr = ::GetLastError();

    switch( dwErr )
    {
      // Error 11010
      // Not documented at http://msdn.microsoft.com/en-us/library/aa366050
      // but has been observed by other users too.
      // Not to be mistaken with WSA_QOS_ADMISSION_FAILURE
      //   ->  Error due to lack of resources
      //
      case IP_REQ_TIMED_OUT:    // 11010
        Log( " � Timed Out" );
        break;

      default:
        Log( "Error: " + String( dwErr ) );
        break;
    }
  }

  ::IcmpCloseHandle( hIcmpFile );
}
// ---------------------------------------------------------------------------
void __fastcall TfrmMain::btnPingv4Click( TObject *Sender )
{
  // http://support.microsoft.com/kb/170591
  // Note that the Winsock 1.1 WSAStartup function must be called prior to using
  // the functions exposed by ICMP.DLL. If you do not do this, the first call to
  // IcmpSendEcho will fail with error 10091 (WSASYSNOTREADY).

  WSADATA AWSAData;
  int AWSAStartupRes = ::WSAStartup( MAKEWORD( 1, 1 ), &AWSAData );

  // WSASYSNOTREADY
  // WSAVERNOTSUPPORTED
  // WSAEINPROGRESS
  // WSAEPROCLIM
  // WSAEFAULT
  if ( 0 != AWSAStartupRes )
    throw Exception( "WSAStartup() failed, Error: " + IntToStr( AWSAStartupRes ) );

  Memo1->Lines->Clear( );
  Application->ProcessMessages();

  try
  {
    const int cMaxEchoCount = 4;

    for( int i = 0; i < cMaxEchoCount; ++i )
    {
      SendPing( edIPv4Address->Text, "< message check >" );

      if( ( cMaxEchoCount - 1 ) != i )
      {
        Log( "" );
        ::Sleep( 1000 );
      }
    }
  }

  __finally
  {
    // return errors possible:
    // WSANOTINITIALISED  - cannot occur here since we definitely initialized WSA
    // WSAENETDOWN
    // WSAEINPROGRESS
    ::WSACleanup();
  }
}
// ---------------------------------------------------------------------------
void __fastcall TfrmMain::Log( const System::String &AMsg )
{
  Memo1->Lines->Add( AMsg );
}
// ---------------------------------------------------------------------------

