//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
  TLabeledEdit *edIPv4Address;
  TButton *btnPingv4;
  TMemo *Memo1;
  void __fastcall btnPingv4Click(TObject *Sender);
private:	// User declarations
  void __fastcall Log( const System::String &AMsg );
  void __fastcall SendPing( const AnsiString &AIPv4Address, const AnsiString &AMessage );

public:		// User declarations
  __fastcall TfrmMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
