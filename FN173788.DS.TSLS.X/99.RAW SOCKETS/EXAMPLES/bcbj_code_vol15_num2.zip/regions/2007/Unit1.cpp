
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------

#include <vector>
HRGN BitmapToRegion(
  Graphics::TBitmap* Bitmap,
  BYTE alphaT = 128
  )
{
  // will hold a handle to the bitmap region
  HRGN hBmpRgn = NULL;

  // fill a vector with single-pixel-tall
  // rectangles corresponding to the
  // non-transparent pixels of the bitmap

  std::vector<RECT> rects;
  int const w = Bitmap->Width;
  int const h = Bitmap->Height;
  // at most, the number of rectangles will
  // be half the number of pixels in the
  // bitmap (this is the worst-case scenario
  // which happens only if the image is a
  // pixel-wise checkerboard)
  rects.reserve(w/2 * h);

  // scan the image...
  for (int y = 0; y < h; ++y)
  {
    RGBQUAD* const p_row =
      reinterpret_cast<RGBQUAD* const>(
        Bitmap->ScanLine[y]
        );
    bool start_new_rect = true;
    for (int x = 0; x < w;++x)
    {
      // if we're on an opaque pixel
      if (p_row[x].rgbReserved >= alphaT)
      {
        if (start_new_rect)
        {
          start_new_rect = false;

          // start a new rectangle starting
          // at the current pixel
          RECT const rect = {x, y, x+1, y+1};
          rects.push_back(rect);
        }
        else
        {
          // increase the width of the
          // current rectangle
          ++rects.back().right;
        }
      }
      // we're on a transparent pixel
      else
      {
        start_new_rect = true;
      }
    }
  }

  // now that the vector of rectangles is
  // initialized, let's create the region
  // in batches of 1000 RECTs

  // total number of rects
  UINT num_rects = rects.size();
  // number of rects per batch
  UINT const num_rects_batch =
    std::min(1000U, num_rects);

  // allocate memory for the batch
  UINT const data_size =
    sizeof(RGNDATAHEADER) +
    num_rects_batch * sizeof(RECT);
  std::vector<BYTE> data(data_size);

  // intialize a RGNDATA structure for the
  // batch of rects
  RGNDATA* const p_rgn_data =
    reinterpret_cast<RGNDATA*>(&data[0]);
  p_rgn_data->rdh.dwSize =
    sizeof(RGNDATAHEADER);
  p_rgn_data->rdh.iType = RDH_RECTANGLES;

  // create the composite region...
  int rect_idx = 0;
  while (num_rects > 0)
  {
    // set the number of rects in the batch
    p_rgn_data->rdh.nCount = std::min(
      num_rects_batch, num_rects
      );
    // decrement the total count
    num_rects -= p_rgn_data->rdh.nCount;

    // fill the batch by copying from the
    // vector of rects to the RGNDATA's
    // Buffer memory
    std::memcpy(
      p_rgn_data->Buffer, &(rects[rect_idx]),
      p_rgn_data->rdh.nCount * sizeof(RECT)
      );
    rect_idx += p_rgn_data->rdh.nCount;

    // create/combine the region(s)
    HRGN const hBatchRgn = ExtCreateRegion(
      NULL, data_size, p_rgn_data
      );
    if (hBatchRgn != NULL)
    {
      if (hBmpRgn != NULL)
      {
        // combine the current batch region
        // with the previous (total) result
        CombineRgn(hBmpRgn, hBmpRgn,
          hBatchRgn, RGN_OR);
        DeleteObject(hBatchRgn);
      }
      else
      {
        // set total region to the result
        // for the first batch region
        hBmpRgn = hBatchRgn;
      }
    }
  }

  // return the bitmap region
  return hBmpRgn;
}
//---------------------------------------------------------------------------



__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
  HRGN const hBmpRgn =
    BitmapToRegion(Image1->Picture->Bitmap);
  if (!SetWindowRgn(Handle, hBmpRgn, true))
  {
    DeleteObject(hBmpRgn);
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PaintBox1MouseDown(
  TObject *Sender, TMouseButton Button,
  TShiftState Shift, int X, int Y)
{
  ReleaseCapture();
  SNDMSG(Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);   
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PaintBox1Paint(
  TObject *Sender)
{
// --- NOT USED IN THIS EXAMPLE -----------
// Uncomment the following to experiment
// with region-based drawing
// ----------------------------------------
/*
  // create an elliptic region
  HRGN const hRgn = CreateEllipticRgn(
    0, 0, ClientWidth, ClientHeight
    );
  if (hRgn == NULL)
  {
    throw Exception("Error creating region!");
  }

  try
  {
    TCanvas* const PBCanvas =
      PaintBox1->Canvas;

    // use the region as a clipping region
    SelectClipRgn(PBCanvas->Handle, hRgn);

    // fill the form with an image
    // (Image1's Visible property is false,
    // and it's loaded with a bitmap)
    PBCanvas->StretchDraw(ClientRect,
      Image1->Picture->Bitmap);

    // invert the pixels within the region
//    InvertRgn(Canvas->Handle, hRgn);

//    // fill the region with blue
//    Canvas->Brush->Color = clBlue;
//    FillRgn(Canvas->Handle, hRgn,
//      Canvas->Brush->Handle);

    // outline the region with black
    PBCanvas->Brush->Color = clBlack;
    FrameRgn(PBCanvas->Handle, hRgn,
      PBCanvas->Brush->Handle, 15, 3);
  }
  __finally
  {
    // delete the region
    DeleteObject(hRgn);
  }
*/
}
//---------------------------------------------------------------------------
